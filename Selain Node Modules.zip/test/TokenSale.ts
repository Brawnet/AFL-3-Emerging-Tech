import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { parseEther } from "viem";
import { network } from "hardhat";
import { parse } from "node:path";

describe("TerraNusa", async function () {
    const { viem } = await network.connect();
    const [owner, buyer] = await viem.getWalletClients();
    const publicClient = await viem.getPublicClient();

    it("Should Purchase Tokens Successfully", async function () {

        const myToken = await viem.deployContract("TerraNusa", ["TerraNusa", "TRN", 18]);
        const tokenSale = await viem.deployContract("TokenSale", [myToken.address]);
        const tokenForSale = parseEther("10");
        await myToken.write.transfer([tokenSale.address, tokenForSale]);

        const ethAmount = parseEther("1");
        await tokenSale.write.purchase({ account: buyer.account, value: ethAmount });

        const buyerBalance = await myToken.read.balanceOf([buyer.account.address]);
        assert.equal(buyerBalance, parseEther("1"));
    });
});
