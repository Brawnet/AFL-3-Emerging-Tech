import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

const TeranusaLandModule = buildModule("TeranusaLandModule", (m) => {
    const land = m.contract("TeranusaLand");

    return { land };
});

export default TeranusaLandModule;