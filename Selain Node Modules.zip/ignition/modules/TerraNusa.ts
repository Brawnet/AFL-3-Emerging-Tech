import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

export default buildModule("TerraNusaModule", (m) => {
    const token = m.contract("TerraNusa", ["TerraNusa", "TRN", 18n]);
    return { token: token };
});
