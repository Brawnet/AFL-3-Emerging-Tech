import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const deploymentDir = path.join(__dirname, "../ignition/deployments/chain-31337");
const artifactsDir = path.join(deploymentDir, "artifacts");
const frontEndDir = path.join(__dirname, "../frontEnd");

const tokenSalesArtifactPath = path.join(artifactsDir, "TokenSaleModule#TokenSale.json");
const deployedAddressPath = path.join(deploymentDir, "deployed_addresses.json");

fs.copyFileSync(tokenSalesArtifactPath, path.join(frontEndDir, "TokenSale.json"));
fs.copyFileSync(deployedAddressPath, path.join(frontEndDir, "deployed_addresses.json"));

console.log("ABI and deployed addresses copied to front-end directory.");