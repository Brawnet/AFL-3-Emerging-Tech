let provider;
let signer;
let addresses = {}; // Variabel global agar bisa diakses semua fungsi

const connectWalletBtn = document.getElementById("connectWalletBtn");
const walletAddressDisplay = document.getElementById("walletAddress"); // Pastikan ID ini sesuai HTML
const buyTokenBtn = document.getElementById("buyTokenBtn");
const ethAmountInput = document.getElementById("ethAmount");
const statusMessage = document.getElementById("statusMessage");

// 1. Perbaikan Fungsi Load Addresses (Menambahkan eksekusi fungsi)
(async () => {
    try {
        const response = await fetch('deployed_addresses.json');
        addresses = await response.json(); // Simpan ke variabel global
        const saleAddr = addresses["TokenSaleModule#TokenSale"];
        if (saleAddr) {
            console.log("Token Sale deployed at:", saleAddr);
        }
    } catch (e) {
        console.error("Error fetching deployed addresses:", e);
    }
})(); // Menambahkan () di akhir agar fungsi langsung berjalan

function showStatus(message, type = "info") {
    // Menyesuaikan dengan tema TERANUSA (Biru/Hijau/Merah)
    const color = type === "danger" ? "#ff4757" : (type === "success" ? "#00ff88" : "#00d4ff");
    statusMessage.style.color = color;
    statusMessage.textContent = message;
}

// 2. Perbaikan Logika Connect Wallet (Ethers v6)
async function connectWallet() {
    // Perbaikan: Harus !== 'undefined' agar bisa jalan saat wallet ada
    if (typeof window.ethereum !== 'undefined') {
        try {
            // Di Ethers v6 gunakan ethers.BrowserProvider
            provider = new ethers.BrowserProvider(window.ethereum);

            // Meminta akun
            const accounts = await provider.send("eth_requestAccounts", []);
            signer = await provider.getSigner();
            const address = await signer.getAddress();

            walletAddressDisplay.textContent = "CONNECTED: " + address.substring(0, 6) + "..." + address.substring(38);
            connectWalletBtn.textContent = "CONNECTED";
            connectWalletBtn.style.opacity = "0.5";

            showStatus("Wallet connected successfully.", "success");
        } catch (error) {
            console.error("Error connecting wallet:", error);
            showStatus("Connection failed.", "danger");
        }
    } else {
        showStatus("Please install Rabby Wallet!", "danger");
    }
}

// 3. Perbaikan Fungsi Buy Tokens
async function buyTokens() {
    const contractAddress = addresses["TokenSaleModule#TokenSale"];
    const ethAmount = ethAmountInput.value;

    console.log("Memanggil Toko di Alamat:", contractAddress);

    if (!signer) {
        showStatus("Please connect wallet first.", "danger");
        return;
    }

    if (!contractAddress) {
        showStatus("Contract address not found.", "danger");
        return;
    }

    try {
        buyTokenBtn.disabled = true;
        buyTokenBtn.textContent = "PROCESSING...";
        showStatus("Preparing transaction...", "info");

        const response = await fetch('TokenSale.json');
        const artifact = await response.json();

        // Inisialisasi kontrak
        const tokenSaleContract = new ethers.Contract(contractAddress, artifact.abi, signer);

        // Gunakan .purchase() sesuai dengan Hardhat test kamu sebelumnya
        const tx = await tokenSaleContract.purchase({
            value: ethers.parseEther(ethAmount)
        });

        showStatus("Transaction sent! Waiting for confirmation...", "info");
        await tx.wait();

        showStatus("Tokens purchased successfully!", "success");
    } catch (error) {
        console.error("Error during purchase:", error);
        showStatus("Transaction failed.", "danger");
    } finally {
        buyTokenBtn.textContent = "BUY TOKENS";
        buyTokenBtn.disabled = false;
    }
}

connectWalletBtn.addEventListener("click", connectWallet);
buyTokenBtn.addEventListener("click", buyTokens);